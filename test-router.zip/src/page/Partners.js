import React from 'react'

export default function Partners() {
  return (
    <h1>Partners page</h1>
  )
}
