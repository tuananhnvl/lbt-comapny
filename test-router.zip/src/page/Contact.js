import React from 'react'

export default function Contact() {
  return (
    <h1>Contact Page</h1>
  )
}
