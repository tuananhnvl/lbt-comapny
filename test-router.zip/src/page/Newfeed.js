import React from 'react'

export default function Newfeed() {
  return (
    <h1>Newfeed Page</h1>
  )
}
